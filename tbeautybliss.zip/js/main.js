/* ===================================================
   Beauty Bliss – Main JS
   Handles: navbar, hero video slideshow, open/closed badge, booking via WhatsApp, gallery lightbox
   =================================================== */

const $ = (s, p = document) => p.querySelector(s);
const $$ = (s, p = document) => Array.from(p.querySelectorAll(s));

// ---------- Navbar (mobile) ----------
(() => {
  const hamburger = $('#nav-hamburger');
  const navLinks = $('#nav-links');
  hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('open');
    navLinks.classList.toggle('open');
  });
  $$('a', navLinks).forEach(a => a.addEventListener('click', () => {
    hamburger.classList.remove('open');
    navLinks.classList.remove('open');
  }));
})();

// ---------- Hero video slideshow ----------
(() => {
  const wrapper = $('.hero-video-wrapper');
  const videos = $$('.hero-video', wrapper);
  const dotsContainer = $('#hero-nav-dots');
  const prevBtn = $('.hero-nav-btn.prev');
  const nextBtn = $('.hero-nav-btn.next');
  if (!videos.length) return;

  videos.forEach((_, i) => {
    const dot = document.createElement('button');
    dot.className = 'hero-nav-dot' + (i === 0 ? ' active' : '');
    dot.dataset.index = i;
    dot.addEventListener('click', () => goTo(i));
    dotsContainer.appendChild(dot);
  });
  const dots = $$('.hero-nav-dot', dotsContainer);

  let current = 0;
  let timer = null;

  function goTo(index) {
    if (index === current) return;
    videos[current].classList.remove('active');
    dots[current].classList.remove('active');
    current = (index + videos.length) % videos.length;
    videos[current].classList.add('active');
    dots[current].classList.add('active');
  }
  function next() { goTo(current + 1); }
  function prev() { goTo(current - 1); }
  function startAuto() { stopAuto(); timer = setInterval(next, 6000); }
  function stopAuto() { if (timer) { clearInterval(timer); timer = null; } }

  prevBtn?.addEventListener('click', () => { prev(); startAuto(); });
  nextBtn?.addEventListener('click', () => { next(); startAuto(); });
  wrapper?.addEventListener('mouseenter', stopAuto);
  wrapper?.addEventListener('mouseleave', startAuto);

  videos[0].classList.add('active');
  startAuto();
})();

// ---------- Open/Closed badge ----------
(() => {
  const badge = $('#hero-status');
  const dot = badge?.querySelector('.status-dot');
  const text = $('#hero-status-text');
  const update = () => {
    const now = new Date();
    const day = now.getDay();
    const minutes = now.getHours() * 60 + now.getMinutes();
    let open = false;
    if (day >= 1 && day <= 5) open = minutes >= 480 && minutes < 1080;
    else if (day === 6) open = minutes >= 480 && minutes < 960;
    else open = minutes >= 480 && minutes < 780;
    if (dot) dot.classList.toggle('offline', !open);
    if (text) text.textContent = open ? 'ONLINE · OPEN NOW' : 'OFFLINE · CLOSED NOW';
  };
  update();
  setInterval(update, 30000);
})();

// ---------- Gallery Lightbox ----------
(() => {
  const lightbox = document.createElement('div');
  lightbox.id = 'gallery-lightbox';
  lightbox.className = 'lightbox';
  lightbox.innerHTML = `
    <button class="lightbox-close" aria-label="Close">✕</button>
    <button class="lightbox-prev" aria-label="Previous">‹</button>
    <img class="lightbox-img" src="" alt="Gallery image" />
    <button class="lightbox-next" aria-label="Next">›</button>
  `;
  document.body.appendChild(lightbox);

  const items = $$('.gallery-item img');
  let currentIndex = 0;

  items.forEach((img, i) => {
    img.style.cursor = 'zoom-in';
    img.addEventListener('click', () => openLightbox(i));
  });

  function openLightbox(index) {
    currentIndex = index;
    const img = items[index];
    lightbox.querySelector('.lightbox-img').src = img.src;
    lightbox.classList.add('open');
    document.body.style.overflow = 'hidden';
  }

  function closeLightbox() {
    lightbox.classList.remove('open');
    document.body.style.overflow = '';
  }

  function navigate(dir) {
    currentIndex = (currentIndex + dir + items.length) % items.length;
    lightbox.querySelector('.lightbox-img').src = items[currentIndex].src;
  }

  lightbox.querySelector('.lightbox-close').addEventListener('click', closeLightbox);
  lightbox.querySelector('.lightbox-prev').addEventListener('click', () => navigate(-1));
  lightbox.querySelector('.lightbox-next').addEventListener('click', () => navigate(1));
  lightbox.addEventListener('click', e => { if (e.target === lightbox) closeLightbox(); });

  document.addEventListener('keydown', e => {
    if (!lightbox.classList.contains('open')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') navigate(-1);
    if (e.key === 'ArrowRight') navigate(1);
  });
})();

// ---------- Booking form – WhatsApp ----------
$('#booking-form')?.addEventListener('submit', e => {
  e.preventDefault();
  const name = $('#bk-name')?.value.trim();
  const phone = $('#bk-phone')?.value.trim();
  const service = $('#bk-service')?.value;
  const date = $('#bk-date')?.value;
  const time = $('#bk-time')?.value;
  const allergies = $('#bk-allergies')?.value.trim();
  if (!name || !phone || !service || !date || !time) return alert('Please fill in all required fields.');
  const msg = encodeURIComponent(`*Booking Request*\nName: ${name}\nPhone: ${phone}\nService: ${service}\nDate: ${date}\nTime: ${time}\nAllergies: ${allergies || 'None'}`);
  window.open(`https://wa.me/27812477418?text=${msg}`, '_blank');
});

// ---------- Newsletter (simulated) ----------
$('#news-form')?.addEventListener('submit', e => {
  e.preventDefault();
  const email = $('#news-email')?.value.trim();
  const note = $('#news-note');
  if (!email) { note.textContent = 'Enter a valid email.'; note.style.color = '#ff6b6b'; return; }
  note.textContent = 'Subscribed! 🎉 Check your inbox.';
  note.style.color = '#bff0d6';
});

// ---------- Smooth scroll for anchor links ----------
$$('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const href = a.getAttribute('href');
    if (href === '#') return;
    const target = $(href);
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth' });
    }
  });
});

// ---------- Navbar scroll effect ----------
window.addEventListener('scroll', () => {
  const navbar = $('#navbar');
  if (window.scrollY > 60) navbar.classList.add('scrolled');
  else navbar.classList.remove('scrolled');
}, { passive: true });

