/* ===================================================
   Beauty Bliss — AI Assistant "Bliss"
   Chat (text) + Voice using browser speech + Gemini fallback
   Trained on all salon details (services, prices, hours, location)
   =================================================== */

'use strict';

(function () {

  // ── Configuration (Gemini API key) ────────────────
  const GEMINI_KEY = 'AIzaSyDQAb8RN6KoYX5lvR_xktFnbI5SksTq9CYbhudLpELRqsIOm5z-sQ';
  const GEMINI_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_KEY}`;

  // ── Training: all official salon details ──────────
  const KNOWLEDGE = `
BRAND: Beauty Bliss — Luxury Hair & Nail Studio
Tagline: "Nourish Your Natural Glow"
Location: Sandton, Johannesburg, South Africa
Phone / WhatsApp: 081 247 7418
Social: Instagram @beautybliss, TikTok @beautybliss, Facebook Beauty Bliss

SERVICES & PRICES:
- Hair Styling & Scalp Care: from R280 (Precision Cut & Style, Colour & Balayage, Deep Conditioning & Scalp Therapy, Protective Styles)
- Nail Studio & Artistry: from R180 (Gel Manicure/Pedicure, Acrylic Extensions & Full Sets, Custom Nail Art, Nail Repair)
- Professional Makeup: R450 (Full Glam, Bridal & Matric Ball, Natural/Soft Glam, Lessons)
- Eyebrow Tint & Shape: R70 (Brow Tint & Shape, Brow Lamination, Henna Brows)
- Eyelash Extensions: R100 – R200 (Classic/Natural, Hybrid/Volume, Mega Volume, Lash Lift & Tint)
- Wig Installation: R300 (Flawless melt & secure fit)
- Wig Customization: R150 (Plucking, bleaching knots & styling)
- Ponytail Styling: R250 (Sleek, voluminous & long-lasting)

WORKING HOURS:
- Mon–Fri: 8:00 AM – 6:00 PM
- Saturday: 8:00 AM – 4:00 PM
- Sunday: 8:00 AM – 1:00 PM
- Open status shows green LED, closed shows red LED on the website.

BOOKING POLICY:
- Scheduled appointments are prioritised over walk-ins.
- Walk-ins welcome based on artist availability.
- Clients must declare allergies (latex, acrylic monomer, lash glue, brow tint, sensitive skin) when booking.
- 15-minute grace period for late arrivals; later may reduce service time or cancel.
- 24h notice for cancellations/rescheduling.
- Right to refuse service for disrespectful behaviour or contagious conditions.

HOW TO BOOK:
- Use the Book Now button or booking form on the site (sends a WhatsApp message to 081 247 7418).
- Or WhatsApp/call directly.

AFTERCARE: Follow artist aftercare instructions for nail, hair, makeup & lash longevity.
`;

  const SYSTEM_PROMPT = `You are Bliss 💕, the warm, friendly and knowledgeable AI beauty assistant for Beauty Bliss — a luxury hair & nail studio in Sandton, Johannesburg.

PERSONALITY: Bubbly, encouraging, professional. Speak like a real beauty expert who cares. Use occasional beauty emojis (💅 💇 ✨ 💕 👑 💖). Keep replies SHORT (2–3 sentences). State prices clearly when asked. End with encouragement like "You deserve to feel beautiful! 💖"

KNOWLEDGE BASE (use this for all answers):
${KNOWLEDGE}

BEHAVIOUR:
- Always answer from the knowledge base above.
- If asked to book, tell them to tap "Book Now" or send a WhatsApp to 081 247 7418.
- Never invent prices or services not listed.`;

  // ── Conversation memory ───────────────────────────
  const conversationHistory = [
    { role: 'user', parts: [{ text: SYSTEM_PROMPT }] },
    { role: 'model', parts: [{ text: 'Understood! I am Bliss, ready to help Beauty Bliss clients feel gorgeous 💕' }] }
  ];

  // ── State ─────────────────────────────────────────
  let isOpen = false;
  let isLoading = false;
  let currentMode = 'chat';
  let isListening = false;
  let isSpeaking = false;
  let recognition = null;
  let currentSpeech = null;

  // ── Build DOM ─────────────────────────────────────
  function buildWidget() {
    const html = `
    <div class="ai-trigger" id="ai-trigger">
      <div class="ai-bubble-hint" id="ai-hint">Chat with Bliss 💕</div>
      <button class="ai-bubble" id="ai-bubble" aria-label="Open Bliss AI Assistant">
        <span class="ai-bubble-icon" id="ai-bubble-icon">💬</span>
      </button>
    </div>

    <div class="ai-panel" id="ai-panel" role="dialog" aria-label="Bliss Beauty Assistant">
      <div class="ai-panel-header">
        <div class="ai-avatar">💄<span class="ai-avatar-dot"></span></div>
        <div class="ai-info">
          <div class="ai-name">Bliss ✦</div>
          <div class="ai-status">Beauty Bliss Assistant</div>
        </div>
        <div class="ai-header-actions">
          <button class="ai-header-btn" id="ai-clear-btn" aria-label="Clear chat">🗑</button>
          <button class="ai-header-btn" id="ai-close-btn" aria-label="Close">✕</button>
        </div>
      </div>

      <div class="ai-mode-tabs">
        <button class="ai-tab active" data-mode="chat">💬 Chat</button>
        <button class="ai-tab" data-mode="voice">🎙 Voice</button>
      </div>

      <div class="ai-chat-mode" id="ai-chat-mode">
        <div class="ai-messages" id="ai-messages"></div>
        <div class="ai-quick-replies" id="ai-quick-replies">
          <button class="ai-quick-btn" data-msg="What services do you offer?">Services</button>
          <button class="ai-quick-btn" data-msg="What are your prices?">Prices</button>
          <button class="ai-quick-btn" data-msg="What are your opening hours?">Hours</button>
          <button class="ai-quick-btn" data-msg="I want to book an appointment">Book</button>
        </div>
        <div class="ai-input-area">
          <textarea id="ai-input" rows="1" placeholder="Ask Bliss anything…"></textarea>
          <button class="ai-send-btn" id="ai-send-btn" aria-label="Send">➤</button>
        </div>
      </div>

      <div class="ai-voice-mode" id="ai-voice-mode">
        <div class="ai-voice-orb" id="ai-voice-orb" title="Tap to speak">🎙</div>
        <div class="ai-voice-status" id="ai-voice-status">Tap the mic to start talking with Bliss</div>
        <div class="ai-voice-transcript" id="ai-voice-transcript">Your words will appear here…</div>
        <button class="ai-voice-start-btn" id="ai-voice-start-btn">🎙 Start Voice Chat</button>
        <div style="font-size:0.72rem;color:#777;letter-spacing:0.06em;line-height:1.5;max-width:260px;">
          Bliss will speak to you in a warm female voice using your browser's built-in voice engine.
        </div>
      </div>

      <div class="ai-powered">✦ Powered by Beauty Bliss AI · Bliss v2.0</div>
    </div>`;

    const wrapper = document.createElement('div');
    wrapper.innerHTML = html;
    document.body.appendChild(wrapper);
  }

  // ── Init ──────────────────────────────────────────
  function init() {
    buildWidget();
    bindEvents();
    setTimeout(() => addBotMessage("Hi gorgeous! 💕 I'm Bliss, your Beauty Bliss guide. Ask me about our services, prices, or hours — or tap **Book Now** to get started!"), 800);
  }

  // ── Events ────────────────────────────────────────
  function bindEvents() {
    const bubble = document.getElementById('ai-bubble');
    const closeBtn = document.getElementById('ai-close-btn');
    const clearBtn = document.getElementById('ai-clear-btn');
    const sendBtn = document.getElementById('ai-send-btn');
    const input = document.getElementById('ai-input');
    const hint = document.getElementById('ai-hint');

    bubble.addEventListener('click', togglePanel);
    closeBtn.addEventListener('click', closePanel);
    clearBtn.addEventListener('click', () => {
      document.getElementById('ai-messages').innerHTML = '';
      setTimeout(() => addBotMessage("Chat cleared! 💕 How can I help you today?"), 200);
    });
    sendBtn.addEventListener('click', handleSend);
    input.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
    });
    input.addEventListener('input', () => {
      input.style.height = 'auto';
      input.style.height = Math.min(input.scrollHeight, 100) + 'px';
    });

    document.querySelectorAll('.ai-quick-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const msg = btn.dataset.msg;
        addUserMessage(msg);
        document.getElementById('ai-quick-replies').style.display = 'none';
        fetchResponse(msg);
      });
    });

    document.querySelectorAll('.ai-tab').forEach(tab => {
      tab.addEventListener('click', () => switchMode(tab.dataset.mode));
    });

    document.getElementById('ai-voice-start-btn').addEventListener('click', toggleVoice);
    document.getElementById('ai-voice-orb').addEventListener('click', toggleVoice);

    bubble.addEventListener('click', () => { if (hint) hint.style.display = 'none'; }, { once: true });

    document.addEventListener('click', e => {
      const panel = document.getElementById('ai-panel');
      const trigger = document.getElementById('ai-trigger');
      if (isOpen && !panel.contains(e.target) && !trigger.contains(e.target)) closePanel();
    });
  }

  function togglePanel() { isOpen ? closePanel() : openPanel(); }

  function openPanel() {
    isOpen = true;
    document.getElementById('ai-panel').classList.add('open');
    document.getElementById('ai-bubble-icon').textContent = '✕';
    document.getElementById('ai-bubble').style.background = 'linear-gradient(135deg, #1f5c3b, #2e7d52)';
  }

  function closePanel() {
    isOpen = false;
    document.getElementById('ai-panel').classList.remove('open');
    document.getElementById('ai-bubble-icon').textContent = '💬';
    document.getElementById('ai-bubble').style.background = '';
    stopSpeaking();
    stopListening();
  }

  function switchMode(mode) {
    currentMode = mode;
    document.querySelectorAll('.ai-tab').forEach(t => t.classList.remove('active'));
    document.querySelector(`[data-mode="${mode}"]`).classList.add('active');
    const chatMode = document.getElementById('ai-chat-mode');
    const voiceMode = document.getElementById('ai-voice-mode');
    if (mode === 'chat') {
      chatMode.style.display = 'flex';
      voiceMode.classList.remove('active');
      stopListening();
      stopSpeaking();
    } else {
      chatMode.style.display = 'none';
      voiceMode.classList.add('active');
    }
  }

  // ── Chat ──────────────────────────────────────────
  function handleSend() {
    const input = document.getElementById('ai-input');
    const text = input.value.trim();
    if (!text || isLoading) return;
    input.value = '';
    input.style.height = 'auto';
    addUserMessage(text);
    document.getElementById('ai-quick-replies').style.display = 'none';
    fetchResponse(text);
  }

  function addUserMessage(text) {
    const msgs = document.getElementById('ai-messages');
    const div = document.createElement('div');
    div.className = 'ai-msg user';
    div.innerHTML = `<div class="ai-msg-avatar">👤</div><div class="ai-msg-bubble">${escapeHtml(text)}</div>`;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
  }

  function addBotMessage(text) {
    const msgs = document.getElementById('ai-messages');
    const typing = document.getElementById('ai-typing');
    if (typing) typing.remove();
    const div = document.createElement('div');
    div.className = 'ai-msg bot';
    div.innerHTML = `<div class="ai-msg-avatar">💄</div><div class="ai-msg-bubble">${formatMessage(text)}</div>`;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
  }

  function showTyping() {
    const msgs = document.getElementById('ai-messages');
    const div = document.createElement('div');
    div.className = 'ai-typing';
    div.id = 'ai-typing';
    div.innerHTML = `<div class="ai-msg-avatar" style="width:30px;height:30px;border-radius:50%;background:linear-gradient(135deg,#1f5c3b,#2e7d52);display:flex;align-items:center;justify-content:center;font-size:.85rem;">💄</div><div class="ai-typing-dots"><span></span><span></span><span></span></div>`;
    msgs.appendChild(div);
    msgs.scrollTop = msgs.scrollHeight;
  }

  async function fetchResponse(userMessage) {
    if (isLoading) return;
    isLoading = true;
    const sendBtn = document.getElementById('ai-send-btn');
    if (sendBtn) sendBtn.disabled = true;
    showTyping();
    conversationHistory.push({ role: 'user', parts: [{ text: userMessage }] });
    try {
      const response = await fetch(GEMINI_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: conversationHistory,
          generationConfig: { temperature: 0.85, maxOutputTokens: 300, topP: 0.9 }
        })
      });
      if (!response.ok) throw new Error(`API error: ${response.status}`);
      const data = await response.json();
      const reply = data?.candidates?.[0]?.content?.parts?.[0]?.text
        || getOfflineFallback(userMessage);
      conversationHistory.push({ role: 'model', parts: [{ text: reply }] });
      addBotMessage(reply);
      if (currentMode === 'voice') speakText(reply);
    } catch (err) {
      const fallback = getOfflineFallback(userMessage);
      conversationHistory.push({ role: 'model', parts: [{ text: fallback }] });
      addBotMessage(fallback);
      if (currentMode === 'voice') speakText(fallback);
    } finally {
      isLoading = false;
      if (sendBtn) sendBtn.disabled = false;
    }
  }

  // ── Offline fallback responses ────────────────────
  function getOfflineFallback(msg) {
    const m = msg.toLowerCase();
    if (m.includes('price') || m.includes('cost') || m.includes('how much') || m.includes('menu')) {
      return "Here's our price list 💕:\n• Hair Styling — from R280\n• Nails — from R180\n• Makeup — R450\n• Eyebrow Tint — R70\n• Lashes — R100–R200\n• Wig Install — R300 | Customization — R150 | Ponytail — R250\n\nWhatsApp **081 247 7418** to book! ✨";
    }
    if (m.includes('hour') || m.includes('open') || m.includes('time') || m.includes('close')) {
      return "We're open 💕:\n• Mon–Fri: 8 AM – 6 PM\n• Sat: 8 AM – 4 PM\n• Sun: 8 AM – 1 PM\nBookings are prioritised over walk-ins!";
    }
    if (m.includes('book') || m.includes('appointment') || m.includes('schedule') || m.includes('reserve')) {
      return "I'd love to help you book! 💕 Tap **Book Now** above or WhatsApp us at **081 247 7418** with your name, service, date & time. We prioritise appointments over walk-ins!";
    }
    if (m.includes('location') || m.includes('address') || m.includes('where')) {
      return "We're located in **Sandton, Johannesburg** 💕 Find us on the map or WhatsApp **081 247 7418** for directions!";
    }
    if (m.includes('nail')) {
      return "Our Nail Studio offers gel, acrylic, extensions & custom art from **R180** 💅 Book via **Book Now** or WhatsApp **081 247 7418**!";
    }
    if (m.includes('hair') || m.includes('wig')) {
      return "We do cuts, colour, scalp therapy & wig installs (R300) 💇 Book via **Book Now** or WhatsApp **081 247 7418**!";
    }
    if (m.includes('makeup') || m.includes('glam')) {
      return "Professional makeup is **R450** — glam, bridal & matric ball ✨ Book via **Book Now** or WhatsApp **081 247 7418**!";
    }
    if (m.includes('lash') || m.includes('brow') || m.includes('eyebrow')) {
      return "Lashes R100–R200 💕 | Brow tint & shape R70. Book via **Book Now** or WhatsApp **081 247 7418**!";
    }
    if (m.includes('hi') || m.includes('hello') || m.includes('hey')) {
      return "Hi gorgeous! 💕 I'm Bliss. Ask me about our services, prices, or hours — or tap **Book Now** to get started!";
    }
    return "Thanks for reaching out! 💕 You can ask me about our services, prices, or hours. To book, tap **Book Now** or WhatsApp **081 247 7418**. You deserve to feel beautiful! 💖";
  }

  // ── Voice ────────────────────────────────────────
  function toggleVoice() {
    if (isListening) { stopListening(); return; }
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      document.getElementById('ai-voice-status').textContent = 'Voice not supported in this browser 💕';
      return;
    }
    if (!('speechSynthesis' in window)) {
      document.getElementById('ai-voice-status').textContent = 'Speech output not supported 💕';
      return;
    }
    startListening();
  }

  function startListening() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SR();
    recognition.lang = 'en-ZA';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    isListening = true;
    const orb = document.getElementById('ai-voice-orb');
    const btn = document.getElementById('ai-voice-start-btn');
    const statusEl = document.getElementById('ai-voice-status');
    orb.classList.add('listening');
    orb.textContent = '🎙';
    btn.textContent = '⏹ Stop Listening';
    statusEl.textContent = '🎙 Listening… speak now';

    recognition.onresult = async (e) => {
      const transcript = e.results[0][0].transcript;
      isListening = false;
      orb.classList.remove('listening');
      btn.textContent = '🎙 Start Voice Chat';
      statusEl.textContent = '💭 Bliss is thinking…';
      orb.textContent = '⏳';
      conversationHistory.push({ role: 'user', parts: [{ text: transcript }] });
      try {
        const response = await fetch(GEMINI_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ contents: conversationHistory, generationConfig: { temperature: 0.85, maxOutputTokens: 200, topP: 0.9 } })
        });
        const data = await response.json();
        const reply = data?.candidates?.[0]?.content?.parts?.[0]?.text || getOfflineFallback(transcript);
        conversationHistory.push({ role: 'model', parts: [{ text: reply }] });
        document.getElementById('ai-voice-transcript').textContent = '💬 ' + reply;
        speakText(reply);
      } catch {
        const fallback = getOfflineFallback(transcript);
        document.getElementById('ai-voice-transcript').textContent = '💬 ' + fallback;
        speakText(fallback);
      }
    };

    recognition.onerror = (e) => {
      isListening = false;
      orb.classList.remove('listening');
      statusEl.textContent = `Oops: ${e.error}. Please try again 💕`;
      btn.textContent = '🎙 Start Voice Chat';
      orb.textContent = '🎙';
    };

    recognition.start();
  }

  function stopListening() {
    if (recognition) { recognition.stop(); recognition = null; }
    isListening = false;
    const orb = document.getElementById('ai-voice-orb');
    if (orb) { orb.classList.remove('listening'); orb.textContent = '🎙'; }
    const btn = document.getElementById('ai-voice-start-btn');
    if (btn) btn.textContent = '🎙 Start Voice Chat';
  }

  function speakText(text) {
    if (!('speechSynthesis' in window)) return;
    stopSpeaking();
    const clean = text
      .replace(/\*\*(.*?)\*\*/g, '$1')
      .replace(/\*(.*?)\*/g, '$1')
      .replace(/[💅💇✨💕👑💖💄🌿🎙⏳]/g, '')
      .replace(/\s+/g, ' ').trim();
    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.rate = 0.97;
    utterance.pitch = 1.1;
    utterance.volume = 1;
    const voices = window.speechSynthesis.getVoices();
    const femaleVoice =
      voices.find(v => /samantha|victoria|karen|zira|female|woman|girl|nova|ava|aria|google uk english female|google us english/i.test(v.name)) ||
      voices.find(v => v.lang.startsWith('en-ZA')) ||
      voices.find(v => v.lang.startsWith('en'));
    if (femaleVoice) utterance.voice = femaleVoice;
    const orb = document.getElementById('ai-voice-orb');
    utterance.onstart = () => {
      isSpeaking = true;
      if (orb) { orb.classList.add('speaking'); orb.textContent = '🔊'; }
      const statusEl = document.getElementById('ai-voice-status');
      if (statusEl) statusEl.textContent = '🔊 Bliss is speaking…';
    };
    utterance.onend = () => {
      isSpeaking = false;
      if (orb) { orb.classList.remove('speaking'); orb.textContent = '🎙'; }
      const statusEl = document.getElementById('ai-voice-status');
      if (statusEl) statusEl.textContent = 'Tap to speak again 💕';
    };
    currentSpeech = utterance;
    window.speechSynthesis.speak(utterance);
  }

  function stopSpeaking() {
    if ('speechSynthesis' in window) window.speechSynthesis.cancel();
    isSpeaking = false;
    const orb = document.getElementById('ai-voice-orb');
    if (orb) { orb.classList.remove('speaking'); orb.textContent = '🎙'; }
  }

  // ── Helpers ───────────────────────────────────────
  function escapeHtml(str) {
    return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function formatMessage(text) {
    return text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/\n/g, '<br>');
  }
  if ('speechSynthesis' in window) {
    window.speechSynthesis.getVoices();
    window.speechSynthesis.addEventListener('voiceschanged', () => window.speechSynthesis.getVoices());
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
