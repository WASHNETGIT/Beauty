/* ===================================================
   TBeautyBliss — Service Worker (v5)
   Network-First strategy: Ensures live updates show immediately,
   falls back to cache when offline.
   =================================================== */

const CACHE_NAME = 'tbeautybliss-v5';

const ASSETS = [
  './',
  './index.html',
  './css/style.css',
  './css/assistant.css',
  './js/main.js',
  './js/assistant.js',
  './images/logo.jpg',
  './images/flyer.jpg',
  './images/hero-bg.jpg',
  './images/hair-1.jpg',
  './images/hair-2.jpg',
  './images/hair-3.jpg',
  './images/makeup-1.jpg',
  './images/makeup-2.jpg',
  './images/nails-1.jpg',
  './images/nails-2.jpg',
  './images/nails-3.jpg',
  './images/nails-4.jpg',
  './images/nails-5.jpg',
  './images/nails-6.jpg',
  './images/brows-1.jpg',
];

// Install — pre-cache all assets & skip waiting immediately
self.addEventListener('install', event => {
  self.skipWaiting();
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(ASSETS))
  );
});

// Activate — immediately delete old caches & claim clients
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch — Network-first, fallback to cache (instant live updates!)
self.addEventListener('fetch', event => {
  if (event.request.method !== 'GET') return;

  event.respondWith(
    fetch(event.request)
      .then(networkResponse => {
        if (networkResponse && networkResponse.status === 200) {
          const clone = networkResponse.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        }
        return networkResponse;
      })
      .catch(() => {
        return caches.match(event.request).then(cachedResponse => {
          if (cachedResponse) return cachedResponse;
          if (event.request.destination === 'document') {
            return caches.match('./index.html');
          }
        });
      })
  );
});
